package com.example3.ApplicationPropertiesWithManyFieldsDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApplicationPropertiesWithManyFieldsDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApplicationPropertiesWithManyFieldsDemoApplication.class, args);
	}

}
