package com.example2.ApplicationPropertiesDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApplicationPropertiesDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApplicationPropertiesDemoApplication.class, args);
	}

}
